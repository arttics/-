package com.familysos.emergency.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import com.familysos.emergency.MainViewModel
import com.familysos.emergency.data.EmergencyContact

@Composable
fun MainStatusScreen(
    viewModel: MainViewModel,
    onRequestAccessibility: () -> Unit,
    onRequestSmsPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRequestLocationPermission: () -> Unit,
    onRequestBatteryOptimization: () -> Unit,
    onOpenSamsungBackgroundSettings: () -> Unit,
    onNavigateToContacts: () -> Unit,
    onNavigateToTest: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToDiagnostics: () -> Unit
) {
    val status by viewModel.status.collectAsState()
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("לחצן מצוקה", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (status.ready) "המערכת פעילה" else "נדרשת הגדרה",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                item { StatusRow("שירות לחצן המצוקה", status.accessibilityEnabled, onRequestAccessibility) }
                item { StatusRow("שליחת SMS", status.smsPermission, onRequestSmsPermission) }
                item { StatusRow("אנשי קשר למצוקה (${status.enabledContacts})", status.enabledContacts > 0, onNavigateToContacts) }
                item { StatusRow("בדיקת לחצן", status.buttonTestPassed, onNavigateToTest) }
                item { StatusRow("מיקום (אופציונלי)", status.locationPermission, onRequestLocationPermission, essential = false) }
                item { StatusRow("התראות", status.notificationPermission, onRequestNotificationPermission, essential = false) }
                item { StatusRow("החרגת חיסכון בסוללה", status.batteryExempt, onRequestBatteryOptimization, essential = false) }
                if (status.manufacturer.contains("samsung", ignoreCase = true)) {
                    item {
                        OutlinedButton(onClick = onOpenSamsungBackgroundSettings, modifier = Modifier.fillMaxWidth()) {
                            Text("הגדרות Samsung - Never sleeping apps")
                        }
                    }
                }
                item {
                    HorizontalDivider()
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onNavigateToContacts, modifier = Modifier.fillMaxWidth()) { Text("אנשי קשר למצוקה") }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onNavigateToTest, modifier = Modifier.fillMaxWidth()) { Text("בדיקת מערכת") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onNavigateToHistory, modifier = Modifier.fillMaxWidth()) { Text("היסטוריית אירועים") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onNavigateToDiagnostics, modifier = Modifier.fillMaxWidth()) { Text("אבחון מערכת") }
                }
            }
        }
    }
}

@Composable
private fun StatusRow(label: String, ok: Boolean, onClick: () -> Unit, essential: Boolean = true) {
    Card(modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontWeight = FontWeight.SemiBold)
                if (!essential) Text("מומלץ אך אינו חוסם SOS", style = MaterialTheme.typography.bodySmall)
            }
            Text(if (ok) "✓ פעיל" else "! דורש הגדרה")
        }
    }
}

@Composable
fun ContactsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val contacts by viewModel.contacts.collectAsState()
    var showDialog by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<EmergencyContact?>(null) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("אנשי קשר למצוקה", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onBack) { Text("חזרה") }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { editing = null; showDialog = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("הוספת איש קשר")
                }
                Spacer(Modifier.height(12.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                    items(contacts, key = { it.id }) { contact ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(contact.name, fontWeight = FontWeight.Bold)
                                        Text(contact.phoneNumber)
                                    }
                                    Switch(checked = contact.enabled, onCheckedChange = { viewModel.setContactEnabled(contact.id, it) })
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { editing = contact; showDialog = true }) { Text("עריכה") }
                                    TextButton(onClick = { viewModel.deleteContact(contact.id) }) { Text("מחיקה") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        ContactDialog(
            initial = editing,
            onDismiss = { showDialog = false },
            onSave = { name, phone ->
                val existing = editing
                if (existing == null) viewModel.addContact(name, phone)
                else viewModel.updateContact(existing.copy(name = name.trim(), phoneNumber = phone.trim()))
                showDialog = false
            }
        )
    }
}

@Composable
private fun ContactDialog(initial: EmergencyContact?, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember(initial) { mutableStateOf(initial?.name.orEmpty()) }
    var phone by remember(initial) { mutableStateOf(initial?.phoneNumber.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "הוספת איש קשר" else "עריכת איש קשר") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("שם") }, singleLine = true)
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("מספר טלפון") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = { onSave(name, phone) }, enabled = name.isNotBlank() && phone.isNotBlank()) { Text("שמירה") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ביטול") } }
    )
}

@Composable
fun TestScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val message by viewModel.testMessage.collectAsState()
    val active by viewModel.buttonTestActive.collectAsState()
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("בדיקת מערכת", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = { viewModel.cancelButtonTest(); onBack() }) { Text("חזרה") }
            }
            Text("בדיקת הכפתור אינה שולחת SMS. היא רק מאמתת שהטלפון מזהה החזקה של 4 שניות.")
            Button(onClick = { viewModel.startButtonTest() }, modifier = Modifier.fillMaxWidth()) {
                Text(if (active) "ממתינה ללחיצה..." else "בדיקת לחצן ללא שליחת הודעה")
            }
            OutlinedButton(onClick = { viewModel.sendTestSms() }, modifier = Modifier.fillMaxWidth()) {
                Text("שליחת הודעת בדיקה")
            }
            message?.let { Text(it, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun HistoryScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val history by viewModel.history.collectAsState()
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("היסטוריית אירועים", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onBack) { Text("חזרה") }
            }
            if (history.isEmpty()) Text("אין אירועים שמורים")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(history, key = { it.id }) { event ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(event.formattedDateTime, fontWeight = FontWeight.Bold)
                            Text("כפתור: ${event.triggerButton}")
                            Text(event.deviceStatusSummary)
                            event.locationUrl?.let { Text("מיקום: $it") }
                        }
                    }
                }
            }
            OutlinedButton(onClick = { viewModel.clearHistory() }, modifier = Modifier.fillMaxWidth()) { Text("ניקוי היסטוריה") }
        }
    }
}

@Composable
fun DiagnosticsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val status by viewModel.status.collectAsState()
    val clipboard = LocalClipboardManager.current
    val report = buildString {
        appendLine("FamilySOS diagnostics")
        appendLine("Device: ${status.manufacturer} ${status.model}")
        appendLine("Android: ${status.androidVersion} / API ${status.apiLevel}")
        appendLine("Accessibility: ${status.accessibilityEnabled}")
        appendLine("SMS permission: ${status.smsPermission}")
        appendLine("Emergency contacts: ${status.enabledContacts}")
        appendLine("Button test: ${status.buttonTestPassed}")
        appendLine("Location: ${status.locationPermission}")
        appendLine("Notifications: ${status.notificationPermission}")
        appendLine("Battery exemption: ${status.batteryExempt}")
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("אבחון מערכת", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                TextButton(onClick = onBack) { Text("חזרה") }
            }
            Text(report)
            Button(onClick = { clipboard.setText(AnnotatedString(report)) }, modifier = Modifier.fillMaxWidth()) {
                Text("העתקת דוח אבחון")
            }
        }
    }
}
