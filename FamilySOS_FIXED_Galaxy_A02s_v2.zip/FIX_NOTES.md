# תיקונים שבוצעו בגרסה זו

- נוספו MainViewModel, מסכי Compose ו-FamilySOSTheme.
- נוספו מודלי EmergencyContact, RecipientSmsStatus ו-SosEvent.
- נוספו EmergencyContactRepository, SettingsRepository ו-EventHistoryRepository עם DataStore מקומי.
- נוסף EmergencyMessageSender ומימוש SMS עם PendingIntent לקבלת תוצאת שליחה.
- תוקן SosAccessibilityService: onAccessibilityEvent/onInterrupt, זיהוי לחיצה 4 שניות לפי state נוכחי, ביטול בשחרור, מניעת key-repeat וכפל אירועים.
- מצב בדיקת כפתור אינו שולח SMS ומוגבל ל-30 שניות.
- נוסף cooldown למניעת SOS כפול כאשר שני כפתורי הווליום נלחצים יחד.
- LocationProvider מממש בדיקת הרשאות ומיקום בפועל במקום placeholder.
- הודעת SOS ראשית נשלחת בלי להמתין ל-GPS.
- נוספו הרשאות פעילות אמיתיות ב-MainActivity.
- נוסף BootReceiver.
- נוסף Theme.FamilySOS ב-themes.xml.
- נוספה התאמה ל-Samsung Never sleeping apps.
- Gradle עודכן ל-8.10.2 ב-workflow וב-properties.
- נוסף proguard-rules.pro.

הערה: סביבת העבודה שבה נערכו הקבצים אינה כוללת Android SDK, לכן אימות הקומפילציה הסופי צריך להתבצע באמצעות GitHub Actions. Build מוצלח עדיין מחייב בדיקות פיזיות על Galaxy A02s.

## 2026-09-03 - Compose weight compile fix
Removed the invalid direct import `androidx.compose.foundation.layout.weight` from `Screens.kt`.
`Modifier.weight(...)` calls remain inside `RowScope`/`ColumnScope`, where the scoped extension resolves correctly.
This addresses the GitHub Actions Kotlin compiler error:
`Cannot access 'val RowColumnParentData?.weight: Float': it is internal in file.`
