package com.familysos.emergency.sender

import com.familysos.emergency.data.EmergencyContact
import com.familysos.emergency.data.RecipientSmsStatus

interface EmergencyMessageSender {
    suspend fun sendEmergencyMessage(
        recipients: List<EmergencyContact>,
        message: String
    ): List<RecipientSmsStatus>
}
