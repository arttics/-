package com.familysos.emergency.sender

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import com.familysos.emergency.data.EmergencyContact
import com.familysos.emergency.data.RecipientSmsStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume

class DeviceSmsMessageSender(private val context: Context) : EmergencyMessageSender {

    override suspend fun sendEmergencyMessage(
        recipients: List<EmergencyContact>,
        message: String
    ): List<RecipientSmsStatus> = withContext(Dispatchers.IO) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return@withContext recipients.map {
                RecipientSmsStatus(it.name, it.phoneNumber, false, "הרשאת SEND_SMS לא ניתנה")
            }
        }

        coroutineScope {
            recipients.map { contact ->
                async {
                    withTimeoutOrNull(20_000L) { sendToContact(contact, message) }
                        ?: RecipientSmsStatus(contact.name, contact.phoneNumber, false, "לא התקבל אישור שליחה בזמן")
                }
            }.awaitAll()
        }
    }

    private suspend fun sendToContact(
        contact: EmergencyContact,
        message: String
    ): RecipientSmsStatus = suspendCancellableCoroutine { continuation ->
        val cleanNumber = contact.phoneNumber.filterNot { it.isWhitespace() || it == '-' || it == '(' || it == ')' }
        if (cleanNumber.isBlank()) {
            continuation.resume(RecipientSmsStatus(contact.name, contact.phoneNumber, false, "מספר טלפון ריק"))
            return@suspendCancellableCoroutine
        }

        val smsManager = context.getSystemService(SmsManager::class.java)
        val parts = smsManager.divideMessage(message)
        val action = "${context.packageName}.SMS_SENT.${UUID.randomUUID()}"
        val remaining = AtomicInteger(parts.size.coerceAtLeast(1))
        val failed = AtomicBoolean(false)
        val failureMessage = arrayOfNulls<String>(1)
        val completed = AtomicBoolean(false)

        lateinit var receiver: BroadcastReceiver
        fun finish(success: Boolean, error: String? = null) {
            if (!completed.compareAndSet(false, true)) return
            runCatching { context.unregisterReceiver(receiver) }
            if (continuation.isActive) {
                continuation.resume(
                    RecipientSmsStatus(
                        name = contact.name,
                        phoneNumber = contact.phoneNumber,
                        isSuccess = success,
                        errorMessage = error
                    )
                )
            }
        }

        receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (resultCode != Activity.RESULT_OK) {
                    failed.set(true)
                    failureMessage[0] = when (resultCode) {
                        SmsManager.RESULT_ERROR_GENERIC_FAILURE -> "כשל כללי בשליחת SMS"
                        SmsManager.RESULT_ERROR_NO_SERVICE -> "אין שירות סלולרי"
                        SmsManager.RESULT_ERROR_NULL_PDU -> "שגיאת PDU"
                        SmsManager.RESULT_ERROR_RADIO_OFF -> "הרדיו הסלולרי כבוי"
                        else -> "שליחת SMS נכשלה (קוד $resultCode)"
                    }
                }
                if (remaining.decrementAndGet() <= 0) {
                    finish(!failed.get(), failureMessage[0])
                }
            }
        }

        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(action),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        continuation.invokeOnCancellation {
            runCatching { context.unregisterReceiver(receiver) }
        }

        try {
            if (parts.size > 1) {
                val sentIntents = ArrayList<PendingIntent>(parts.size)
                parts.indices.forEach { index ->
                    sentIntents += PendingIntent.getBroadcast(
                        context,
                        (System.nanoTime() + index).toInt(),
                        Intent(action).setPackage(context.packageName),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                }
                smsManager.sendMultipartTextMessage(cleanNumber, null, parts, sentIntents, null)
            } else {
                val sentIntent = PendingIntent.getBroadcast(
                    context,
                    System.nanoTime().toInt(),
                    Intent(action).setPackage(context.packageName),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                smsManager.sendTextMessage(cleanNumber, null, message, sentIntent, null)
            }
        } catch (e: Exception) {
            finish(false, e.localizedMessage ?: e.javaClass.simpleName)
        }
    }
}
