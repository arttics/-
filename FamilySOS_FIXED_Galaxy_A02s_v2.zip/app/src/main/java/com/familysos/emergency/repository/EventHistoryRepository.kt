package com.familysos.emergency.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.familysos.emergency.data.RecipientSmsStatus
import com.familysos.emergency.data.SosEvent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class EventHistoryRepository private constructor(private val context: Context) {
    private val historyKey = stringPreferencesKey("event_history_v1")

    val historyFlow: Flow<List<SosEvent>> = context.familySosDataStore.data.map { prefs ->
        decodeHistory(prefs[historyKey].orEmpty()).sortedByDescending { it.timestamp }
    }

    suspend fun addEvent(event: SosEvent) {
        context.familySosDataStore.edit { prefs ->
            val current = decodeHistory(prefs[historyKey].orEmpty())
            val updated = (listOf(event) + current).distinctBy { it.id }.take(50)
            prefs[historyKey] = encodeHistory(updated)
        }
    }

    suspend fun clear() {
        context.familySosDataStore.edit { it.remove(historyKey) }
    }

    private fun encodeHistory(events: List<SosEvent>): String = events.joinToString("\n") { event ->
        val statuses = event.smsResults.joinToString(",") { status ->
            listOf(
                encodeField(status.name),
                encodeField(status.phoneNumber),
                status.isSuccess.toString(),
                encodeField(status.errorMessage.orEmpty())
            ).joinToString("~")
        }
        listOf(
            encodeField(event.id),
            event.timestamp.toString(),
            encodeField(event.formattedDateTime),
            event.isTest.toString(),
            encodeField(event.triggerButton),
            event.smsAttempted.toString(),
            encodeField(statuses),
            event.locationAvailable.toString(),
            encodeField(event.locationUrl.orEmpty()),
            encodeField(event.deviceStatusSummary)
        ).joinToString("|")
    }

    private fun decodeHistory(raw: String): List<SosEvent> = raw.lineSequence()
        .filter { it.isNotBlank() }
        .mapNotNull { line ->
            val parts = line.split('|')
            if (parts.size != 10) return@mapNotNull null
            val statusesRaw = decodeField(parts[6])
            val statuses = if (statusesRaw.isBlank()) emptyList() else statusesRaw.split(',').mapNotNull { item ->
                val s = item.split('~')
                if (s.size != 4) null else RecipientSmsStatus(
                    name = decodeField(s[0]),
                    phoneNumber = decodeField(s[1]),
                    isSuccess = s[2].toBooleanStrictOrNull() ?: false,
                    errorMessage = decodeField(s[3]).ifBlank { null }
                )
            }
            SosEvent(
                id = decodeField(parts[0]),
                timestamp = parts[1].toLongOrNull() ?: 0L,
                formattedDateTime = decodeField(parts[2]),
                isTest = parts[3].toBooleanStrictOrNull() ?: false,
                triggerButton = decodeField(parts[4]),
                smsAttempted = parts[5].toBooleanStrictOrNull() ?: false,
                smsResults = statuses,
                locationAvailable = parts[7].toBooleanStrictOrNull() ?: false,
                locationUrl = decodeField(parts[8]).ifBlank { null },
                deviceStatusSummary = decodeField(parts[9])
            )
        }
        .filter { it.id.isNotBlank() }
        .toList()

    companion object {
        @Volatile private var INSTANCE: EventHistoryRepository? = null
        fun getInstance(context: Context): EventHistoryRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: EventHistoryRepository(context.applicationContext).also { INSTANCE = it }
            }
    }
}
