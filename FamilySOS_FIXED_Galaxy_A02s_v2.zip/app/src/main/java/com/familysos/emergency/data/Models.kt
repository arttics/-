package com.familysos.emergency.data

data class EmergencyContact(
    val id: String,
    val name: String,
    val phoneNumber: String,
    val enabled: Boolean = true
)

data class RecipientSmsStatus(
    val name: String,
    val phoneNumber: String,
    val isSuccess: Boolean,
    val errorMessage: String? = null
)

data class SosEvent(
    val id: String,
    val timestamp: Long,
    val formattedDateTime: String,
    val isTest: Boolean,
    val triggerButton: String,
    val smsAttempted: Boolean,
    val smsResults: List<RecipientSmsStatus>,
    val locationAvailable: Boolean,
    val locationUrl: String?,
    val deviceStatusSummary: String
)
