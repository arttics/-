package com.familysos.emergency.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.familysos.emergency.data.EmergencyContact
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

class EmergencyContactRepository private constructor(private val context: Context) {
    private val contactsKey = stringPreferencesKey("emergency_contacts_v1")

    val contactsFlow: Flow<List<EmergencyContact>> = context.familySosDataStore.data.map { prefs ->
        decodeContacts(prefs[contactsKey].orEmpty())
    }

    suspend fun getEnabledContacts(): List<EmergencyContact> =
        contactsFlow.first().filter { it.enabled && it.phoneNumber.isNotBlank() }

    suspend fun addContact(name: String, phoneNumber: String) {
        val trimmedName = name.trim()
        val trimmedPhone = phoneNumber.trim()
        if (trimmedName.isBlank() || trimmedPhone.isBlank()) return
        updateAll { current ->
            current + EmergencyContact(
                id = UUID.randomUUID().toString(),
                name = trimmedName,
                phoneNumber = trimmedPhone,
                enabled = true
            )
        }
    }

    suspend fun updateContact(contact: EmergencyContact) {
        updateAll { list -> list.map { if (it.id == contact.id) contact else it } }
    }

    suspend fun deleteContact(id: String) {
        updateAll { list -> list.filterNot { it.id == id } }
    }

    suspend fun setEnabled(id: String, enabled: Boolean) {
        updateAll { list -> list.map { if (it.id == id) it.copy(enabled = enabled) else it } }
    }

    private suspend fun updateAll(transform: (List<EmergencyContact>) -> List<EmergencyContact>) {
        context.familySosDataStore.edit { prefs ->
            val current = decodeContacts(prefs[contactsKey].orEmpty())
            prefs[contactsKey] = encodeContacts(transform(current))
        }
    }

    private fun encodeContacts(list: List<EmergencyContact>): String = list.joinToString("\n") { contact ->
        listOf(
            encodeField(contact.id),
            encodeField(contact.name),
            encodeField(contact.phoneNumber),
            contact.enabled.toString()
        ).joinToString("|")
    }

    private fun decodeContacts(raw: String): List<EmergencyContact> = raw.lineSequence()
        .filter { it.isNotBlank() }
        .mapNotNull { line ->
            val parts = line.split('|')
            if (parts.size != 4) return@mapNotNull null
            EmergencyContact(
                id = decodeField(parts[0]),
                name = decodeField(parts[1]),
                phoneNumber = decodeField(parts[2]),
                enabled = parts[3].toBooleanStrictOrNull() ?: true
            )
        }
        .toList()

    companion object {
        @Volatile private var INSTANCE: EmergencyContactRepository? = null
        fun getInstance(context: Context): EmergencyContactRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: EmergencyContactRepository(context.applicationContext).also { INSTANCE = it }
            }
    }
}
