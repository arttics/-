package com.familysos.emergency.repository

import android.content.Context
import androidx.datastore.preferences.preferencesDataStore

val Context.familySosDataStore by preferencesDataStore(name = "family_sos_settings")
