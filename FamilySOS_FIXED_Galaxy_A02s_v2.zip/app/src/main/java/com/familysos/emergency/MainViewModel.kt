package com.familysos.emergency

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.familysos.emergency.data.EmergencyContact
import com.familysos.emergency.data.SosEvent
import com.familysos.emergency.repository.EmergencyContactRepository
import com.familysos.emergency.repository.EventHistoryRepository
import com.familysos.emergency.repository.SettingsRepository
import com.familysos.emergency.sender.DeviceSmsMessageSender
import com.familysos.emergency.util.SystemChecks
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application.applicationContext
    private val contactsRepo = EmergencyContactRepository.getInstance(app)
    private val settingsRepo = SettingsRepository.getInstance(app)
    private val historyRepo = EventHistoryRepository.getInstance(app)
    private val sender = DeviceSmsMessageSender(app)

    val contacts: StateFlow<List<EmergencyContact>> = contactsRepo.contactsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val history: StateFlow<List<SosEvent>> = historyRepo.historyFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val buttonTestActive = SosAccessibilityService.isTestModeActive

    private val _status = MutableStateFlow(SystemStatus())
    val status = _status.asStateFlow()

    private val _testMessage = MutableStateFlow<String?>(null)
    val testMessage = _testMessage.asStateFlow()
    private var buttonTestTimeoutJob: Job? = null

    init {
        viewModelScope.launch {
            contacts.collect { refreshSystemStatus() }
        }
        viewModelScope.launch {
            SosAccessibilityService.lastTestDetection.collect { detection ->
                if (detection != null) {
                    buttonTestTimeoutJob?.cancel()
                    settingsRepo.setButtonTestPassed(true)
                    _testMessage.value = "לחצן המצוקה זוהה בהצלחה: ${detection.buttonName}"
                    refreshSystemStatus()
                    SosAccessibilityService.clearLastTestDetection()
                }
            }
        }
        refreshSystemStatus()
    }

    fun refreshSystemStatus() {
        viewModelScope.launch {
            val enabledContacts = contacts.value.count { it.enabled && it.phoneNumber.isNotBlank() }
            val testPassed = settingsRepo.buttonTestPassedFlow.first()
            _status.value = SystemStatus(
                accessibilityEnabled = SystemChecks.isAccessibilityEnabled(app),
                smsPermission = SystemChecks.hasSmsPermission(app),
                notificationPermission = SystemChecks.hasNotificationPermission(app),
                locationPermission = SystemChecks.hasEmergencyLocationPermission(app),
                batteryExempt = SystemChecks.isIgnoringBatteryOptimizations(app),
                enabledContacts = enabledContacts,
                buttonTestPassed = testPassed,
                manufacturer = Build.MANUFACTURER ?: "",
                model = Build.MODEL ?: "",
                androidVersion = Build.VERSION.RELEASE ?: "",
                apiLevel = Build.VERSION.SDK_INT
            )
        }
    }

    fun addContact(name: String, phone: String) = viewModelScope.launch {
        contactsRepo.addContact(name, phone)
    }

    fun updateContact(contact: EmergencyContact) = viewModelScope.launch {
        contactsRepo.updateContact(contact)
    }

    fun deleteContact(id: String) = viewModelScope.launch {
        contactsRepo.deleteContact(id)
    }

    fun setContactEnabled(id: String, enabled: Boolean) = viewModelScope.launch {
        contactsRepo.setEnabled(id, enabled)
    }

    fun startButtonTest() {
        buttonTestTimeoutJob?.cancel()
        _testMessage.value = "החזיקי את אחד מכפתורי הווליום במשך 4 שניות"
        SosAccessibilityService.startButtonTest()
        buttonTestTimeoutJob = viewModelScope.launch {
            delay(30_000L)
            if (SosAccessibilityService.isTestModeActive.value) {
                SosAccessibilityService.cancelButtonTest()
                _testMessage.value = "בדיקת הכפתור הסתיימה ללא זיהוי. אפשר לנסות שוב."
            }
        }
    }

    fun cancelButtonTest() {
        buttonTestTimeoutJob?.cancel()
        SosAccessibilityService.cancelButtonTest()
        _testMessage.value = null
    }

    fun sendTestSms() = viewModelScope.launch {
        val enabled = contactsRepo.getEnabledContacts()
        if (enabled.isEmpty()) {
            _testMessage.value = "אין אנשי קשר פעילים לשליחת בדיקה"
            return@launch
        }
        _testMessage.value = "שולחת הודעת בדיקה..."
        val results = sender.sendEmergencyMessage(
            enabled,
            "זוהי הודעת בדיקה ממערכת לחצן המצוקה. אין צורך בפעולה."
        )
        val ok = results.count { it.isSuccess }
        _testMessage.value = "הודעת בדיקה: $ok מתוך ${results.size} נשלחו בהצלחה"
    }

    fun clearHistory() = viewModelScope.launch { historyRepo.clear() }

    data class SystemStatus(
        val accessibilityEnabled: Boolean = false,
        val smsPermission: Boolean = false,
        val notificationPermission: Boolean = false,
        val locationPermission: Boolean = false,
        val batteryExempt: Boolean = false,
        val enabledContacts: Int = 0,
        val buttonTestPassed: Boolean = false,
        val manufacturer: String = "",
        val model: String = "",
        val androidVersion: String = "",
        val apiLevel: Int = 0
    ) {
        val ready: Boolean
            get() = accessibilityEnabled && smsPermission && enabledContacts > 0 && buttonTestPassed
    }
}
