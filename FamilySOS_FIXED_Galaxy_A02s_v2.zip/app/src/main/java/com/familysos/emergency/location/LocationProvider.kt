package com.familysos.emergency.location

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

class LocationProvider(private val context: Context) {
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun hasBackgroundLocationPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun getFreshLastKnownLocation(): Location? {
        if (!hasLocationPermission()) return null
        return try {
            val candidates = mutableListOf<Location>()
            val providers = locationManager.getProviders(true)
            for (provider in providers) {
                runCatching { locationManager.getLastKnownLocation(provider) }.getOrNull()?.let(candidates::add)
            }
            val newest = candidates.maxByOrNull { it.time }
            val tenMinutesAgo = System.currentTimeMillis() - 10 * 60 * 1000L
            newest?.takeIf { it.time >= tenMinutesAgo }
        } catch (_: SecurityException) {
            null
        }
    }

    suspend fun requestSingleLocationUpdate(timeoutMs: Long): Location? {
        if (!hasLocationPermission() || !hasBackgroundLocationPermission()) return null
        val providers = preferredProviders()
        if (providers.isEmpty()) return null

        return withTimeoutOrNull(timeoutMs) {
            for (provider in providers) {
                val result = requestFromProvider(provider)
                if (result != null) return@withTimeoutOrNull result
            }
            null
        }
    }

    private fun preferredProviders(): List<String> {
        val enabled = runCatching { locationManager.getProviders(true) }.getOrDefault(emptyList())
        return listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .filter { enabled.contains(it) }
            .ifEmpty { enabled }
    }

    private suspend fun requestFromProvider(provider: String): Location? = suspendCancellableCoroutine { cont ->
        if (!hasLocationPermission()) {
            cont.resume(null)
            return@suspendCancellableCoroutine
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val cancellationSignal = CancellationSignal()
                cont.invokeOnCancellation { cancellationSignal.cancel() }
                val executor = ContextCompat.getMainExecutor(context)
                locationManager.getCurrentLocation(provider, cancellationSignal, executor) { location ->
                    if (cont.isActive) cont.resume(location)
                }
            } else {
                @Suppress("DEPRECATION")
                val listener = object : LocationListener {
                    override fun onLocationChanged(location: Location) {
                        runCatching { locationManager.removeUpdates(this) }
                        if (cont.isActive) cont.resume(location)
                    }
                    @Deprecated("Deprecated in Android")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                    override fun onProviderEnabled(provider: String) = Unit
                    override fun onProviderDisabled(provider: String) {
                        runCatching { locationManager.removeUpdates(this) }
                        if (cont.isActive) cont.resume(null)
                    }
                }
                cont.invokeOnCancellation { runCatching { locationManager.removeUpdates(listener) } }
                @Suppress("DEPRECATION")
                locationManager.requestSingleUpdate(provider, listener, null)
            }
        } catch (_: SecurityException) {
            if (cont.isActive) cont.resume(null)
        } catch (_: Exception) {
            if (cont.isActive) cont.resume(null)
        }
    }

    companion object {
        fun formatMapsUrl(location: Location): String =
            "https://maps.google.com/?q=${location.latitude},${location.longitude}"
    }
}
