package com.familysos.emergency.repository

import android.util.Base64

internal fun encodeField(value: String): String =
    Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

internal fun decodeField(value: String): String = runCatching {
    String(Base64.decode(value, Base64.NO_WRAP), Charsets.UTF_8)
}.getOrDefault("")
