package com.familysos.emergency

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import androidx.core.app.NotificationCompat
import android.os.Vibrator
import android.os.VibratorManager
import com.familysos.emergency.data.SosEvent
import com.familysos.emergency.location.LocationProvider
import com.familysos.emergency.repository.EmergencyContactRepository
import com.familysos.emergency.repository.EventHistoryRepository
import com.familysos.emergency.repository.SettingsRepository
import com.familysos.emergency.sender.DeviceSmsMessageSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class SosTriggerManager private constructor(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val contactsRepo = EmergencyContactRepository.getInstance(context)
    private val settingsRepo = SettingsRepository.getInstance(context)
    private val historyRepo = EventHistoryRepository.getInstance(context)
    private val locationProvider = LocationProvider(context)
    private val messageSender = DeviceSmsMessageSender(context)

    fun triggerSos(triggerButtonName: String) {
        scope.launch {
            val now = System.currentTimeMillis()
            val formattedDate = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now))
            val enabledContacts = contactsRepo.getEnabledContacts()

            vibrateEmergency()

            if (enabledContacts.isEmpty()) {
                vibrateFailure()
                postFailureNotification("לא מוגדר איש קשר פעיל לקבלת הודעת מצוקה")
                historyRepo.addEvent(
                    SosEvent(
                        id = UUID.randomUUID().toString(),
                        timestamp = now,
                        formattedDateTime = formattedDate,
                        isTest = false,
                        triggerButton = triggerButtonName,
                        smsAttempted = false,
                        smsResults = emptyList(),
                        locationAvailable = false,
                        locationUrl = null,
                        deviceStatusSummary = "אין אנשי קשר פעילים"
                    )
                )
                return@launch
            }

            val freshLocation = locationProvider.getFreshLastKnownLocation()
            val primaryMessage = buildString {
                append("אני במצוקה. נא ליצור איתי קשר מיד.\n")
                append(formattedDate)
                if (freshLocation != null) {
                    append("\nזה המיקום האחרון שלי:\n")
                    append(LocationProvider.formatMapsUrl(freshLocation))
                }
            }

            val smsResults = messageSender.sendEmergencyMessage(enabledContacts, primaryMessage)

            if (smsResults.none { it.isSuccess }) {
                vibrateFailure()
                postFailureNotification("לא ניתן היה לשלוח את הודעת המצוקה")
            }

            historyRepo.addEvent(
                SosEvent(
                    id = UUID.randomUUID().toString(),
                    timestamp = now,
                    formattedDateTime = formattedDate,
                    isTest = false,
                    triggerButton = triggerButtonName,
                    smsAttempted = true,
                    smsResults = smsResults,
                    locationAvailable = freshLocation != null,
                    locationUrl = freshLocation?.let(LocationProvider::formatMapsUrl),
                    deviceStatusSummary = "נשלח בהצלחה ל-${smsResults.count { it.isSuccess }} מתוך ${smsResults.size} אנשי קשר"
                )
            )

            // Never delay the primary emergency message for GPS.
            if (freshLocation == null && locationProvider.hasLocationPermission()) {
                val acquired = locationProvider.requestSingleLocationUpdate(15_000)
                if (acquired != null) {
                    val secondMessage = "המיקום שלי:\n${LocationProvider.formatMapsUrl(acquired)}"
                    messageSender.sendEmergencyMessage(enabledContacts, secondMessage)
                }
            }
        }
    }

    fun vibrateTestSuccess() {
        scope.launch { vibrate(longArrayOf(0, 120, 90, 120)) }
    }

    private suspend fun vibrateEmergency() {
        if (!settingsRepo.vibrationEnabledFlow.first()) return
        vibrate(longArrayOf(0, 300, 150, 300, 150, 500))
    }

    private fun vibrateFailure() {
        vibrate(longArrayOf(0, 180, 100, 180, 100, 180, 100, 600))
    }

    private fun postFailureNotification(message: String) {
        runCatching {
            val manager = context.getSystemService(NotificationManager::class.java)
            val channelId = "familysos_emergency_failures"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager.createNotificationChannel(
                    NotificationChannel(channelId, "התראות לחצן מצוקה", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val openApp = PendingIntent.getActivity(
                context,
                2001,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            manager.notify(
                2001,
                NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(android.R.drawable.ic_dialog_alert)
                    .setContentTitle("לחצן המצוקה דורש בדיקה")
                    .setContentText(message)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .setContentIntent(openApp)
                    .build()
            )
        }
    }

    private fun vibrate(pattern: LongArray) {
        runCatching {
            val effect = VibrationEffect.createWaveform(pattern, -1)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService(VibratorManager::class.java)
                manager?.defaultVibrator?.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(effect)
            }
        }
    }

    companion object {
        @Volatile private var INSTANCE: SosTriggerManager? = null

        fun getInstance(context: Context): SosTriggerManager =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: SosTriggerManager(context.applicationContext).also { INSTANCE = it }
            }
    }
}
