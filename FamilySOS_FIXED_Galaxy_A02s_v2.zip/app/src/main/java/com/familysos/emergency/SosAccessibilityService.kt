package com.familysos.emergency

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class SosAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var triggerManager: SosTriggerManager

    private var volumeUpStartTime = 0L
    private var volumeUpPressed = false
    private var volumeUpTriggered = false
    private var volumeUpRunnable: Runnable? = null

    private var volumeDownStartTime = 0L
    private var volumeDownPressed = false
    private var volumeDownTriggered = false
    private var volumeDownRunnable: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        triggerManager = SosTriggerManager.getInstance(this)
        _isServiceActive.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> handleVolumeUp(event)
            KeyEvent.KEYCODE_VOLUME_DOWN -> handleVolumeDown(event)
            else -> return super.onKeyEvent(event)
        }
        // Do not consume the key. Short presses should keep controlling volume normally.
        return false
    }

    private fun handleVolumeUp(event: KeyEvent) {
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (volumeUpPressed) return // ignore key-repeat events
                volumeUpPressed = true
                volumeUpTriggered = false
                volumeUpStartTime = SystemClock.elapsedRealtime()
                val runnable = Runnable {
                    val elapsed = SystemClock.elapsedRealtime() - volumeUpStartTime
                    if (volumeUpPressed && !volumeUpTriggered && elapsed >= HOLD_THRESHOLD_MS) {
                        volumeUpTriggered = true
                        handleConfirmedLongPress("Volume Up")
                    }
                }
                volumeUpRunnable = runnable
                handler.postDelayed(runnable, HOLD_THRESHOLD_MS)
            }
            KeyEvent.ACTION_UP -> resetVolumeUp()
        }
    }

    private fun handleVolumeDown(event: KeyEvent) {
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (volumeDownPressed) return // ignore key-repeat events
                volumeDownPressed = true
                volumeDownTriggered = false
                volumeDownStartTime = SystemClock.elapsedRealtime()
                val runnable = Runnable {
                    val elapsed = SystemClock.elapsedRealtime() - volumeDownStartTime
                    if (volumeDownPressed && !volumeDownTriggered && elapsed >= HOLD_THRESHOLD_MS) {
                        volumeDownTriggered = true
                        handleConfirmedLongPress("Volume Down")
                    }
                }
                volumeDownRunnable = runnable
                handler.postDelayed(runnable, HOLD_THRESHOLD_MS)
            }
            KeyEvent.ACTION_UP -> resetVolumeDown()
        }
    }

    private fun handleConfirmedLongPress(buttonName: String) {
        val testIsValid = _isTestModeActive.value && SystemClock.elapsedRealtime() <= testModeExpiresAt
        if (testIsValid) {
            _lastTestDetection.value = ButtonTestDetection(buttonName, System.currentTimeMillis())
            _isTestModeActive.value = false
            testModeExpiresAt = 0L
            lastSosTriggerElapsed = SystemClock.elapsedRealtime()
            triggerManager.vibrateTestSuccess()
            return
        }
        if (_isTestModeActive.value) {
            _isTestModeActive.value = false
            testModeExpiresAt = 0L
        }
        val nowElapsed = SystemClock.elapsedRealtime()
        if (nowElapsed - lastSosTriggerElapsed < SOS_COOLDOWN_MS) return
        lastSosTriggerElapsed = nowElapsed
        triggerManager.triggerSos(triggerButtonName = buttonName)
    }

    private fun resetVolumeUp() {
        volumeUpRunnable?.let(handler::removeCallbacks)
        volumeUpRunnable = null
        volumeUpPressed = false
        volumeUpTriggered = false
        volumeUpStartTime = 0L
    }

    private fun resetVolumeDown() {
        volumeDownRunnable?.let(handler::removeCallbacks)
        volumeDownRunnable = null
        volumeDownPressed = false
        volumeDownTriggered = false
        volumeDownStartTime = 0L
    }

    override fun onDestroy() {
        resetVolumeUp()
        resetVolumeDown()
        _isServiceActive.value = false
        super.onDestroy()
    }

    companion object {
        const val HOLD_THRESHOLD_MS = 4000L

        data class ButtonTestDetection(val buttonName: String, val timestamp: Long)

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive = _isServiceActive.asStateFlow()

        private val _isTestModeActive = MutableStateFlow(false)
        val isTestModeActive = _isTestModeActive.asStateFlow()

        private val _lastTestDetection = MutableStateFlow<ButtonTestDetection?>(null)
        val lastTestDetection = _lastTestDetection.asStateFlow()
        @Volatile private var testModeExpiresAt: Long = 0L
        @Volatile private var lastSosTriggerElapsed: Long = Long.MIN_VALUE / 2
        private const val SOS_COOLDOWN_MS = 10_000L

        fun startButtonTest() {
            _lastTestDetection.value = null
            testModeExpiresAt = SystemClock.elapsedRealtime() + 30_000L
            _isTestModeActive.value = true
        }

        fun cancelButtonTest() {
            _isTestModeActive.value = false
            testModeExpiresAt = 0L
        }

        fun clearLastTestDetection() {
            _lastTestDetection.value = null
        }
    }
}
