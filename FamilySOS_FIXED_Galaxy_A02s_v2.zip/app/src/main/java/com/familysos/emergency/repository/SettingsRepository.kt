package com.familysos.emergency.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SettingsRepository private constructor(private val context: Context) {
    private val vibrationKey = booleanPreferencesKey("vibration_enabled")
    private val buttonTestPassedKey = booleanPreferencesKey("button_test_passed")

    val vibrationEnabledFlow: Flow<Boolean> = context.familySosDataStore.data.map { prefs ->
        prefs[vibrationKey] ?: true
    }

    val buttonTestPassedFlow: Flow<Boolean> = context.familySosDataStore.data.map { prefs ->
        prefs[buttonTestPassedKey] ?: false
    }

    suspend fun setVibrationEnabled(enabled: Boolean) {
        context.familySosDataStore.edit { it[vibrationKey] = enabled }
    }

    suspend fun setButtonTestPassed(passed: Boolean) {
        context.familySosDataStore.edit { it[buttonTestPassedKey] = passed }
    }

    companion object {
        @Volatile private var INSTANCE: SettingsRepository? = null
        fun getInstance(context: Context): SettingsRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsRepository(context.applicationContext).also { INSTANCE = it }
            }
    }
}
