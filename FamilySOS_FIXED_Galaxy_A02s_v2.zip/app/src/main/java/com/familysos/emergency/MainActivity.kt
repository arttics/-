package com.familysos.emergency

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import com.familysos.emergency.ui.ContactsScreen
import com.familysos.emergency.ui.DiagnosticsScreen
import com.familysos.emergency.ui.HistoryScreen
import com.familysos.emergency.ui.MainStatusScreen
import com.familysos.emergency.ui.TestScreen
import com.familysos.emergency.ui.theme.FamilySOSTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    private val smsPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        viewModel.refreshSystemStatus()
    }

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        viewModel.refreshSystemStatus()
    }

    private val locationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        viewModel.refreshSystemStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var screen by rememberSaveable { mutableStateOf("main") }
            FamilySOSTheme {
                when (screen) {
                    "contacts" -> ContactsScreen(viewModel) { screen = "main" }
                    "test" -> TestScreen(viewModel) { screen = "main" }
                    "history" -> HistoryScreen(viewModel) { screen = "main" }
                    "diagnostics" -> DiagnosticsScreen(viewModel) { screen = "main" }
                    else -> MainStatusScreen(
                        viewModel = viewModel,
                        onRequestAccessibility = { openAccessibilitySettings() },
                        onRequestSmsPermission = { smsPermissionLauncher.launch(Manifest.permission.SEND_SMS) },
                        onRequestNotificationPermission = { requestNotifications() },
                        onRequestLocationPermission = { requestLocation() },
                        onRequestBatteryOptimization = { openBatteryOptimizationRequest() },
                        onOpenSamsungBackgroundSettings = { openSamsungNeverSleepingApps() },
                        onNavigateToContacts = { screen = "contacts" },
                        onNavigateToTest = { screen = "test" },
                        onNavigateToHistory = { screen = "history" },
                        onNavigateToDiagnostics = { screen = "diagnostics" }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemStatus()
    }

    private fun openAccessibilitySettings() {
        runCatching {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }.onFailure {
            openAppDetails()
        }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            viewModel.refreshSystemStatus()
        }
    }

    private fun requestLocation() {
        val hasForeground =
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (!hasForeground) {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            // Android 11+ requires the caregiver to choose "Allow all the time" in app settings.
            openAppDetails()
        } else {
            viewModel.refreshSystemStatus()
        }
    }

    private fun openBatteryOptimizationRequest() {
        val packageUri = Uri.parse("package:$packageName")
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, packageUri)
        runCatching { startActivity(intent) }
            .onFailure {
                runCatching { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                    .onFailure { openAppDetails() }
            }
    }

    private fun openSamsungNeverSleepingApps() {
        val samsungIntent = Intent("com.samsung.android.sm.ACTION_OPEN_CHECKABLE_LISTACTIVITY").apply {
            setPackage("com.samsung.android.lool")
            putExtra("activity_type", 2)
        }
        runCatching { startActivity(samsungIntent) }
            .onFailure { openAppDetails() }
    }

    private fun openAppDetails() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
        )
    }
}
