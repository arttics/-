// Main Jetpack Compose Entrypoint
package com.familysos.emergency

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.familysos.emergency.ui.*
import com.familysos.emergency.ui.theme.FamilySOSTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FamilySOSTheme {
                MainStatusScreen(
                    viewModel = viewModel,
                    onRequestAccessibility = {},
                    onRequestSmsPermission = {},
                    onRequestNotificationPermission = {},
                    onRequestLocationPermission = {},
                    onRequestBatteryOptimization = {},
                    onNavigateToContacts = {},
                    onNavigateToTest = {},
                    onNavigateToHistory = {},
                    onNavigateToDiagnostics = {}
                )
            }
        }
    }
}
