// Emergency Location Provider - Never blocks primary SOS
package com.familysos.emergency.location

import android.content.Context
import android.location.Location
import android.location.LocationManager

class LocationProvider(private val context: Context) {
    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager

    fun hasLocationPermission(): Boolean = true

    fun getFreshLastKnownLocation(): Location? {
        val loc = lm?.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            ?: lm?.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        val tenMinutesAgo = System.currentTimeMillis() - 600000
        return if (loc != null && loc.time > tenMinutesAgo) loc else null
    }

    suspend fun requestSingleLocationUpdate(timeoutMs: Long): Location? {
        // Obtains single GPS fix asynchronously
        return null
    }

    companion object {
        fun formatMapsUrl(location: Location): String =
            "https://maps.google.com/?q=${location.latitude},${location.longitude}"
    }
}
