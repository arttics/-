// Native SmsManager sender
package com.familysos.emergency.sender

import android.content.Context
import android.telephony.SmsManager
import com.familysos.emergency.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DeviceSmsMessageSender(private val context: Context) : EmergencyMessageSender {
    override suspend fun sendEmergencyMessage(
        recipients: List<EmergencyContact>,
        message: String
    ): List<RecipientSmsStatus> = withContext(Dispatchers.IO) {
        val smsManager = context.getSystemService(SmsManager::class.java)
        recipients.map { contact ->
            try {
                val clean = contact.phoneNumber.replace(" ", "").replace("-", "")
                val parts = smsManager.divideMessage(message)
                if (parts.size > 1) {
                    smsManager.sendMultipartTextMessage(clean, null, parts, null, null)
                } else {
                    smsManager.sendTextMessage(clean, null, message, null, null)
                }
                RecipientSmsStatus(contact.name, contact.phoneNumber, true)
            } catch (e: Exception) {
                RecipientSmsStatus(contact.name, contact.phoneNumber, false, e.localizedMessage)
            }
        }
    }
}
