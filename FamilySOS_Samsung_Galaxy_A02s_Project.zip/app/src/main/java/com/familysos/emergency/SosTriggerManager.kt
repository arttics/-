// Emergency SOS Trigger Manager
// Sends primary SMS immediately without waiting for GPS
// Handles vibration, Hebrew TTS, location append, fallback SMS
package com.familysos.emergency

import android.content.Context
import com.familysos.emergency.data.*
import com.familysos.emergency.location.LocationProvider
import com.familysos.emergency.sender.DeviceSmsMessageSender
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class SosTriggerManager private constructor(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val contactsRepo = EmergencyContactRepository.getInstance(context)
    private val settingsRepo = SettingsRepository.getInstance(context)
    private val historyRepo = EventHistoryRepository.getInstance(context)
    private val locationProvider = LocationProvider(context)
    private val messageSender = DeviceSmsMessageSender(context)

    fun triggerSos(triggerButtonName: String, isTest: Boolean = false) {
        scope.launch {
            val now = System.currentTimeMillis()
            val formattedDate = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now))

            val enabledContacts = contactsRepo.getEnabledContacts()
            if (enabledContacts.isEmpty()) return@launch

            // 1. Get reasonably recent location if immediately available
            val freshLocation = locationProvider.getFreshLastKnownLocation()
            val primaryMessage = buildString {
                append("אני במצוקה. נא ליצור איתי קשר מיד.\n")
                append(formattedDate)
                if (freshLocation != null) {
                    append("\nזה המיקום האחרון שלי:\n")
                    append(LocationProvider.formatMapsUrl(freshLocation))
                }
            }

            // 2. Dispatch primary SMS immediately
            val smsResults = messageSender.sendEmergencyMessage(enabledContacts, primaryMessage)

            // 3. Record event
            historyRepo.addEvent(
                SosEvent(
                    id = UUID.randomUUID().toString(),
                    timestamp = now,
                    formattedDateTime = formattedDate,
                    isTest = isTest,
                    triggerButton = triggerButtonName,
                    smsAttempted = true,
                    smsResults = smsResults,
                    locationAvailable = freshLocation != null,
                    locationUrl = freshLocation?.let { LocationProvider.formatMapsUrl(it) },
                    deviceStatusSummary = "נשלח ל-${smsResults.count { it.isSuccess }} אנשי קשר"
                )
            )

            // 4. If fresh GPS was not immediately available, acquire in background and send 2nd SMS
            if (freshLocation == null && locationProvider.hasLocationPermission()) {
                val acquired = locationProvider.requestSingleLocationUpdate(15000)
                if (acquired != null) {
                    val secondMsg = "המיקום שלי:\n${LocationProvider.formatMapsUrl(acquired)}"
                    messageSender.sendEmergencyMessage(enabledContacts, secondMsg)
                }
            }
        }
    }

    companion object {
        @Volatile private var INSTANCE: SosTriggerManager? = null
        fun getInstance(context: Context): SosTriggerManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SosTriggerManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
