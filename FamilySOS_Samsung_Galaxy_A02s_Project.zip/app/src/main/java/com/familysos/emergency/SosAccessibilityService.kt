// Continuous 4-second physical volume buttons monitor
// Observes KEYCODE_VOLUME_UP & KEYCODE_VOLUME_DOWN
// Uses SystemClock.elapsedRealtime()
package com.familysos.emergency

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class SosAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var triggerManager: SosTriggerManager

    private var volumeUpStartTime: Long = 0L
    private var isVolumeUpPressed: Boolean = false
    private var hasTriggeredVolumeUp: Boolean = false
    private var volumeUpRunnable: Runnable? = null

    private var volumeDownStartTime: Long = 0L
    private var isVolumeDownPressed: Boolean = false
    private var hasTriggeredVolumeDown: Boolean = false
    private var volumeDownRunnable: Runnable? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        _isServiceActive.value = true
        triggerManager = SosTriggerManager.getInstance(this)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val action = event.action

        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return super.onKeyEvent(event)
        }

        val currentTime = SystemClock.elapsedRealtime()

        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                handleVolumeKey(
                    action = action,
                    keyName = "Volume Up",
                    currentTime = currentTime,
                    isPressed = isVolumeUpPressed,
                    hasTriggered = hasTriggeredVolumeUp,
                    startTime = volumeUpStartTime,
                    setPressed = { isVolumeUpPressed = it },
                    setTriggered = { hasTriggeredVolumeUp = it },
                    setStartTime = { volumeUpStartTime = it },
                    runnableRef = { volumeUpRunnable },
                    setRunnableRef = { volumeUpRunnable = it }
                )
            }

            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                handleVolumeKey(
                    action = action,
                    keyName = "Volume Down",
                    currentTime = currentTime,
                    isPressed = isVolumeDownPressed,
                    hasTriggered = hasTriggeredVolumeDown,
                    startTime = volumeDownStartTime,
                    setPressed = { isVolumeDownPressed = it },
                    setTriggered = { hasTriggeredVolumeDown = it },
                    setStartTime = { volumeDownStartTime = it },
                    runnableRef = { volumeDownRunnable },
                    setRunnableRef = { volumeDownRunnable = it }
                )
            }
        }

        // Return false so normal volume click is NOT consumed
        return false
    }

    private fun handleVolumeKey(
        action: Int,
        keyName: String,
        currentTime: Long,
        isPressed: Boolean,
        hasTriggered: Boolean,
        startTime: Long,
        setPressed: (Boolean) -> Unit,
        setTriggered: (Boolean) -> Unit,
        setStartTime: (Long) -> Unit,
        runnableRef: () -> Runnable?,
        setRunnableRef: (Runnable?) -> Unit
    ) {
        when (action) {
            KeyEvent.ACTION_DOWN -> {
                if (isPressed) return

                setPressed(true)
                setTriggered(false)
                setStartTime(currentTime)

                val runnable = Runnable {
                    val actualElapsed = SystemClock.elapsedRealtime() - startTime
                    if (actualElapsed >= HOLD_THRESHOLD_MS && !hasTriggered) {
                        setTriggered(true)
                        val isTestMode = _isTestModeActive.value
                        triggerManager.triggerSos(triggerButtonName = keyName, isTest = isTestMode)
                    }
                }
                setRunnableRef(runnable)
                handler.postDelayed(runnable, HOLD_THRESHOLD_MS)
            }

            KeyEvent.ACTION_UP -> {
                runnableRef()?.let { handler.removeCallbacks(it) }
                setRunnableRef(null)
                setPressed(false)
                setTriggered(false)
                setStartTime(0L)
            }
        }
    }

    companion object {
        const val HOLD_THRESHOLD_MS = 4000L
        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive = _isServiceActive.asStateFlow()
        val _isTestModeActive = MutableStateFlow(false)
    }
}
