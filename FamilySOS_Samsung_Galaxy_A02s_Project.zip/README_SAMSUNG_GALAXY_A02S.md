# FamilySOS - לחצן מצוקה עבור Samsung Galaxy A02s

גרסה ייעודית למכשיר Samsung Galaxy A02s (מעבד Snapdragon 450, זיכרון 3GB RAM, One UI Core 2.5/3.1/4.1 מבוסס אנדרואיד 10-12).

## הפקת קובץ APK בחינם דרך GitHub Actions (ללא צורך בתוכנות):
1. העלו תיקייה זו ל-GitHub בריפוזיטורי פרטי או ציבורי.
2. עברו ללשונית **Actions**.
3. בחרו ב-**Build FamilySOS APK for Samsung Galaxy A02s** ולחצו **Run workflow**.
4. לאחר כדקה וחצי יופיע קובץ ה-APK להורדה ישירה!

## בנייה מקומית עם Android Studio:
1. פתחו את התיקייה ב-Android Studio.
2. לחצו בתפריט העליון: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. הקובץ המוגמר יימצא בנתיב:
   `app/build/outputs/apk/debug/app-debug.apk`
